import './App.css';
import QuizApp from './components/QuizApp';

function App() {
  return (
    <div className="App">
      <QuizApp />
    </div>
  );
}

export default App;
