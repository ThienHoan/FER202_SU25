// App.js
import React from "react";
import Exercise4 from "./components/ex4";
import Exercise5 from "./components/ex5";
import Exercise6 from "./components/QuestionBank";
function App() {
  return (
    <div>
      <Exercise4 />
      <Exercise5 />
      <Exercise6 />
    </div>
  );
}

export default App;
